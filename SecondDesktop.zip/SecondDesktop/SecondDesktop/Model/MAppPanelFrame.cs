﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace SecondDesktop
{
    class MAppPanelFrame
    {
		public string Icon;
		public string Title;
		public string CloseImage;
	}
}
