﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SecondDesktopDesktopManagerDll
{
    class MSubAppFrame
    {
        public double Width;
        public double Height;

        public string AppImage;
        public string AppTitle;

        public Visibility SettingsButtonVisibility;
    }
}
