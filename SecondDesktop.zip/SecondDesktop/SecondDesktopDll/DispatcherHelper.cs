﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Threading;

namespace SecondDesktopDll
{
    public class DispatcherHelper
    {
        public static Dispatcher UIDispatcher { get; set; }
    }
}
